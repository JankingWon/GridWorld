package Part4;

import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class RockHoundRunner {
    
    public static void main(String[] args) {
      //magic number
        final int zero = 0;
        final int one = 1;
        final int two = 2;
        final int three = 3;
        final int four = 4;
        final int five = 5;
        final int six = 6;
        final int seven = 7;
        final int eight = 8;
        final int nine = 9;
        //构造一个默认的worldRockHoundRunner
        ActorWorld worldRockHoundRunner = new ActorWorld();
        //添加很多的石头观察RockHound是否能真的”吃“掉他们
        worldRockHoundRunner.add(new Location(three, three), new Rock(Color.green));
        worldRockHoundRunner.add(new Location(three, four), new Rock(Color.PINK));
        worldRockHoundRunner.add(new Location(five, four), new Rock(Color.BLUE));
        worldRockHoundRunner.add(new Location(two, eight), new Rock(Color.BLUE));
        worldRockHoundRunner.add(new Location(five, five), new Rock(Color.PINK));
        worldRockHoundRunner.add(new Location(one, five), new Rock(Color.RED));
        worldRockHoundRunner.add(new Location(seven, two), new Rock(Color.YELLOW));
        worldRockHoundRunner.add(new Location(seven, eight), new Rock(Color.green));
        //将RockHound添加到world里面去
        worldRockHoundRunner.add(new Location(four, four), new RockHound());
        worldRockHoundRunner.add(new Location(five, eight), new RockHound());
        //显示GUI
        worldRockHoundRunner.show();

    }

}
