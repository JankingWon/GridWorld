package Part4;

import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class ChameleonKidRunner {
  
    public static void main(String[] args) {
      //magic number
        final int zero = 0;
        final int one = 1;
        final int two = 2;
        final int three = 3;
        final int four = 4;
        final int five = 5;
        final int six = 6;
        final int seven = 7;
        final int eight = 8;
        final int nine = 9;
        //构造一个带有有界grid的world来存放actors
        ActorWorld worldChameleonKidRunner = new ActorWorld();
        //得到很多设置好颜色的石头用于观察ChameleonKid颜色的变化
        worldChameleonKidRunner.add(new Location(three, three), new Rock(Color.green));
        worldChameleonKidRunner.add(new Location(three, four), new Rock(Color.PINK));
        worldChameleonKidRunner.add(new Location(five, four), new Rock(Color.BLUE));
        worldChameleonKidRunner.add(new Location(two, seven), new Rock(Color.BLUE));
        worldChameleonKidRunner.add(new Location(five, five), new Rock(Color.PINK));
        worldChameleonKidRunner.add(new Location(one, five), new Rock(Color.RED));
        worldChameleonKidRunner.add(new Location(seven, two), new Rock(Color.YELLOW));
        worldChameleonKidRunner.add(new Location(seven, eight), new Rock(Color.green));
        //构造两个ChameleonKid并添加到world里面去
        worldChameleonKidRunner.add(new Location(four, four), new ChameleonKid());
        worldChameleonKidRunner.add(new Location(five, eight), new ChameleonKid());
        //显示GUI
        worldChameleonKidRunner.show();
    }

}
