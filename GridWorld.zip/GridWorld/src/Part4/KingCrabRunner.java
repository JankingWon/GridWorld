package Part4;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class KingCrabRunner {
  
    public static void main(String[] args)
    {
        //magic number
        final int zero = 0;
        final int one = 1;
        final int two = 2;
        final int three = 3;
        final int four = 4;
        final int five = 5;
        final int six = 6;
        final int seven = 7;
        final int eight = 8;
        final int nine = 9;
        //默认构造一个带有有界grid的world
        ActorWorld worldKingCrabRunner = new ActorWorld();
        //得到各种的actor类型
        worldKingCrabRunner.add(new Location(seven, five), new Rock());
        worldKingCrabRunner.add(new Location(five, four), new Rock());
        worldKingCrabRunner.add(new Location(five, seven), new Rock());
        worldKingCrabRunner.add(new Location(seven, three), new Rock());
        worldKingCrabRunner.add(new Location(six, zero), new Rock());
        worldKingCrabRunner.add(new Location(six, three), new Rock());
        worldKingCrabRunner.add(new Location(seven, eight), new Flower());
        worldKingCrabRunner.add(new Location(two, two), new Flower());
        worldKingCrabRunner.add(new Location(three, five), new Flower());
        worldKingCrabRunner.add(new Location(three, eight), new Flower());
        worldKingCrabRunner.add(new Location(six, five), new Bug());
        worldKingCrabRunner.add(new Location(five, three), new Bug());
        //得到三个不同位置的kingCrab
        worldKingCrabRunner.add(new Location(four, five), new KingCrab());
        worldKingCrabRunner.add(new Location(six, one), new KingCrab());
        worldKingCrabRunner.add(new Location(seven, four), new KingCrab());
        //得到界面展示
        worldKingCrabRunner.show();
    }
}
