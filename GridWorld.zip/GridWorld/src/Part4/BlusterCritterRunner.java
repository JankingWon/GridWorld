package Part4;
import java.awt.Color;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

public class BlusterCritterRunner {

    public static void main(String[] args){
        //magic number
        final int zero = 0;
        final int one = 1;
        final int two = 2;
        final int three = 3;
        final int four = 4;
        final int five = 5;
        final int six = 6;
        final int seven = 7;
        final int eight = 8;
        final int nine = 9;
        //默认构造一个带有有界grid的world
        ActorWorld worldBlusterCritterRunner = new ActorWorld();
        //构造一系列的Critter
        Critter aCritter = new Critter();
        Critter bCritter = new Critter();
        Critter cCritter = new Critter();
        Critter dCritter = new Critter();
        Critter eCritter = new Critter();
        Critter fCritter = new Critter();
        Critter gCritter = new Critter();
        Critter hCritter = new Critter();
        //为了观察到颜色的变化，设置不同颜色的KingCrab
        aCritter.setColor(Color.green);
        bCritter.setColor(Color.pink);
        cCritter.setColor(Color.LIGHT_GRAY);
        dCritter.setColor(Color.yellow);
        eCritter.setColor(Color.GRAY);
        fCritter.setColor(Color.red);
        gCritter.setColor(Color.cyan);
        hCritter.setColor(Color.black);
        //把这些KingCrab放到world里面去
        worldBlusterCritterRunner.add(new Location(one, three), aCritter);
        worldBlusterCritterRunner.add(new Location(three, five), bCritter);
        worldBlusterCritterRunner.add(new Location(five, three), cCritter);
        worldBlusterCritterRunner.add(new Location(nine, eight), dCritter);
        worldBlusterCritterRunner.add(new Location(two, five), eCritter);
        worldBlusterCritterRunner.add(new Location(one, five), fCritter);
        worldBlusterCritterRunner.add(new Location(seven, zero), gCritter);
        worldBlusterCritterRunner.add(new Location(five, eight), hCritter);
        worldBlusterCritterRunner.add(new Location(six, four), new BlusterCritter(1));
        worldBlusterCritterRunner.add(new Location(five, nine), new BlusterCritter(1));
        //显示GUI
        worldBlusterCritterRunner.show();
    }

}
