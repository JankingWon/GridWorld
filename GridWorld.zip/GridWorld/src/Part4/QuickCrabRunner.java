package Part4;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class QuickCrabRunner {
    public static void main(String[] args)
    {
      //magic number
        final int zero = 0;
        final int one = 1;
        final int two = 2;
        final int three = 3;
        final int four = 4;
        final int five = 5;
        final int six = 6;
        final int seven = 7;
        final int eight = 8;
        final int nine = 9;
        //默认构造一个带有有界grid的worldQuickCrabRunner
        ActorWorld worldQuickCrabRunner = new ActorWorld();
      //添加一些actor类的物体，并把它们都放进world里面去
        worldQuickCrabRunner.add(new Location(seven, five), new Rock());
        worldQuickCrabRunner.add(new Location(five, four), new Rock());
        worldQuickCrabRunner.add(new Location(five, seven), new Rock());
        worldQuickCrabRunner.add(new Location(seven, three), new Rock());
        worldQuickCrabRunner.add(new Location(six, zero), new Rock());
        worldQuickCrabRunner.add(new Location(six, three), new Rock());
        worldQuickCrabRunner.add(new Location(seven, eight), new Flower());
        worldQuickCrabRunner.add(new Location(two, two), new Flower());
        worldQuickCrabRunner.add(new Location(three, five), new Flower());
        worldQuickCrabRunner.add(new Location(three, eight), new Flower());
        worldQuickCrabRunner.add(new Location(six, five), new Bug());
        worldQuickCrabRunner.add(new Location(five, three), new Bug());
        worldQuickCrabRunner.add(new Location(four, five), new QuickCrab());
        worldQuickCrabRunner.add(new Location(six, one), new QuickCrab());
        worldQuickCrabRunner.add(new Location(seven, four), new QuickCrab());
      //显示GUI
        worldQuickCrabRunner.show();
    }
}
